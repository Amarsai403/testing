import { Component } from '@angular/core';

import { EmpService } from './emp.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  peoples;
  changeid = 1;
  data;
  mytitle = '';
  mybody = '';
  mypostdata;
  mypostimge;
  mypostfullname;
  mypostid;
  title = 'app works!';
  constructor(private service: EmpService) {
    this.service.getpeoples().subscribe((data) => {
      this.peoples = data;
    });

  }
  ngOnInit() {
    this.getData(this.changeid);
    this.service.getpost()
    .subscribe((res:any)=>{
      this.mypostdata = JSON.parse(res._body).data;
      this.mypostimge = this.mypostdata.avatar;
      this.mypostfullname = this.mypostdata.first_name + this.mypostdata.last_name;
      this.mypostid = this.mypostdata.id;
      console.log(JSON.parse(res._body).data);
    })
    // console.log( this.service.mypostdatavalues)
  }
  getincrement(){
   
   this.changeid = this.changeid + 1;
  
   this.getData(this.changeid);
  }
  getdecrement(){
    
    this.changeid = this.changeid - 1;
    this.getData(this.changeid);
   }

  getData = (id) => {
    this.service.getjsondata(id).subscribe(
      (mydata) => {

       this.data = mydata;
       this.mytitle = JSON.parse(this.data._body).title;
       this.mybody = JSON.parse(this.data._body).body;
       
        
      }
    );
  }

}
