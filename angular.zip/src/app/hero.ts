export const MYDATA = [

    { name: "John", age: 31, city: "New York" },
    { name: "Sara", age: 22, city: "London" },
    { name: "Michael", age: 25, city: "India" },
];