import { Component, OnInit } from '@angular/core';
import { EmpService } from './emp.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  peoples;
  changeid;
  data;
  mytitle;
  mybody;
  mypostdata;
  mypostimge;
  mypostfullname;
  mypostid;
  myimage;
  checkdata;
  checkdatagetdata;

  constructor(private service: EmpService) {
    this.service.getmydata().subscribe((res:any)=>{
       console.log(res);
    });

  
  }
  ngOnInit() {
    var storgevalue = parseInt(localStorage.getItem('value'));
   this.changeid = storgevalue;
    this.getData(this.changeid);
    this.service.getpostdata().subscribe((response:any)=>{
      console.log(response.data);
      this.checkdata = response;
      this.mypostimge = response.data.avatar;
      this.mypostfullname = response.data.first_name + response.data.last_name; 
      this.mypostid = response.data.id;
    });
    
    };

  getincrement(){
    
    

    var storgevalue = parseInt(localStorage.getItem('value'));
    this.changeid = storgevalue + 1;
    localStorage.setItem('value', JSON.stringify(this.changeid));
    this.getData(this.changeid);
   }
   getdecrement(){
    var storgevalue = parseInt(localStorage.getItem('value'));
     this.changeid = storgevalue - 1;
     localStorage.setItem('value', JSON.stringify(this.changeid));
     this.getData(this.changeid);
    }
 
   getData = (id) => {
     this.service.getjsondata(id).subscribe(
       (mydata:any) => {
         this.checkdatagetdata = mydata;
           console.log(mydata);
      this.mytitle =  mydata.title;
      this.myimage =  mydata.thumbnailUrl;
        
         
       });
       localStorage.setItem('value', JSON.stringify(this.changeid));
   }
}
