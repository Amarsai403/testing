import { Injectable } from '@angular/core';
import { MYDATA } from './hero';
import { Observable  , of } from 'rxjs';
import { HttpClient } from  '@angular/common/http'
@Injectable()
export class EmpService {

  constructor(private http:HttpClient) { 
    
   
   }

getmydata(): Observable<any[]>{
  // return this.mydata = MYDATA;
  return of(MYDATA);
  
  }
getjsondata(id) {
  // return this.http.get(`https://jsonplaceholder.typicode.com/posts/${id}`);
  return this.http.get(`https://jsonplaceholder.typicode.com/photos/${id}`);
  
}
getpostdata(){
  return this.http.post('https://reqres.in/api/users/1',{"data":{"id":1,"first_name":"George","last_name":"Bluth","avatar":"https://s3.amazonaws.com/uifaces/faces/twitter/calebogden/128.jpg"}});
}

}
